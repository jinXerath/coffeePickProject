package com.cp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeePickApplicationTests {

	@Test
	void contextLoads() {
	}

}
