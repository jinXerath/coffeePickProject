package com.cp.admin.notice.controller;

public class NoticeController {

}
