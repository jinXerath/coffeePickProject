package com.cp.admin.notice.service;

public class NoticeServiceImpl {

}
