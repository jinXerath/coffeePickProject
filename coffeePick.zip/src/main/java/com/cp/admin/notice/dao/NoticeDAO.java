package com.cp.admin.notice.dao;

public class NoticeDAO {

}
