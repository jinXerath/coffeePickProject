package com.cp.admin.event.service;

public class EventServiceImpl {

}
