package com.cp.admin.event.service;

public interface EventService {

}
