package com.cp.admin.qna.vo;

public class QnaReplyVO {

}
