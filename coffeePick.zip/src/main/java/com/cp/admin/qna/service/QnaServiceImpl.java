package com.cp.admin.qna.service;

public class QnaServiceImpl {

}
