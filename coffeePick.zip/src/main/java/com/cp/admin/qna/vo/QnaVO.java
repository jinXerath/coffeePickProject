package com.cp.admin.qna.vo;

public class QnaVO {
	private int corpQnaNo;
	private String qna_title;
}
