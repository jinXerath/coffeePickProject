package com.cp.admin.qna.dao;

public class QnaDAO {

}
