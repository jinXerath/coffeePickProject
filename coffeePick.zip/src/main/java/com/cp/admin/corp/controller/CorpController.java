package com.cp.admin.corp.controller;

public class CorpController {

}
