package com.cp.admin.administrator.service;

public interface AdministratorService {

}
