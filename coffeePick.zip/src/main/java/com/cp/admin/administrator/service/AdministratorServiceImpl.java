package com.cp.admin.administrator.service;

public class AdministratorServiceImpl {

}
