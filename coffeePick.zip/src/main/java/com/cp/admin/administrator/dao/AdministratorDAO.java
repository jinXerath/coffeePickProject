package com.cp.admin.administrator.dao;

public class AdministratorDAO {

}
