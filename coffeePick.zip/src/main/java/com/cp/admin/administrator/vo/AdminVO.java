package com.cp.admin.administrator.vo;

import lombok.Data;

@Data
public class AdminVO {
    private String admin_id;
    private String admin_pw;
    private String admin_name;
    private String admin_phone;
    private String admin_email;
    private String admin_regdate;
    private String admin_authority;
}
