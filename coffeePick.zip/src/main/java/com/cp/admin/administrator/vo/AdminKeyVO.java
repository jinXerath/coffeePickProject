package com.cp.admin.administrator.vo;

import lombok.Data;

@Data
public class AdminKeyVO {
	private String admin_key;
}
