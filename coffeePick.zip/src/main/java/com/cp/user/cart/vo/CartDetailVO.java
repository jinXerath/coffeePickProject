package com.cp.user.cart.vo;

import lombok.Data;

@Data
public class CartDetailVO {
	private int cart_detail_no;
	private int cart_detail_menu_quantity;
	private int menu_no;
	private String cart_id;
}
