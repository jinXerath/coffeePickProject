package com.cp.user.point.controller;

public class PointController {

}
