package com.cp.user.point.vo;

import lombok.Data;

@Data
public class PointVO {
	private String member_id;
	private String point_total;
}
