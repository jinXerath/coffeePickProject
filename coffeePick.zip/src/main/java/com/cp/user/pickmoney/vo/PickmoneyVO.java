package com.cp.user.pickmoney.vo;

import lombok.Data;

@Data
public class PickmoneyVO {
	private String member_id;
	private String pickmoney_total;
}
