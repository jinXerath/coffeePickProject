package com.cp.user.pickmoney.dao;

public class PickmoneyDAO {

}
