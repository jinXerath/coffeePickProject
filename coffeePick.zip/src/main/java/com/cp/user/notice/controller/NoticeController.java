package com.cp.user.notice.controller;

public class NoticeController {

}
