package com.cp.user.review.dao;

public class ReviceDAO {

}
