package com.cp.user.review.vo;

public class ReviewVO {
    private int reviewNo;
    private String reviewContent;
    private int reviewRating;
    private String reviewRegDate;
    private String reviewImg;
    private int reviewReportStatus;
    private String orderNo;
    private String storeId;
    private String memberId;
}
