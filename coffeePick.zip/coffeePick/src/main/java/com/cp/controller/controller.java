package com.cp.controller;


import org.apache.catalina.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/member/*")
@Slf4j
public class controller {
	
	/**
	 * 글목록 구현하기(페이징 처리부분과 검색 제외 목록 조회) 요청 URL:http://loaclhost:8080/board/boardList
	 */
	
	@GetMapping("/cart")
	public String cart() {
		log.info("cart 호출 성공");

		
			
		return "member-service/cart";
		}	
}
